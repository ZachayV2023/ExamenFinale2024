package org.depinfo.intra;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import org.depinfo.intra.databinding.ActivitySecondBinding;

public class SecondActivity extends AppCompatActivity {

    private ActivitySecondBinding binding;

    public SecondActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySecondBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Si vous n'arrivez pas à obtenir le Id de l'activité principale, utilisez simplement l'id 25.
        // Cela devrait correspondre au Pokémon Pikachu

        // Vous devez utiliser la méthode assignerImage pour afficher l'image dans l'interface
    }

    /**
     * Définir l'image du Pokémon selon son id.
     *
     * @param imageView Conteneur d'image sur lequel le Pokémon doit être ajoutée.
     * @param id        Id du Pokémon.
     */
    private void assignerImage(ImageView imageView, int id) {
        int imageId = getResources().getIdentifier("@drawable/p" + id, null, getPackageName());
        Drawable res = getResources().getDrawable(imageId, getTheme());
        imageView.setImageDrawable(res);
    }
}
